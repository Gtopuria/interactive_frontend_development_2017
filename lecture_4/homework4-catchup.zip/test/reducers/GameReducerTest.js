import gameReducer from '../../src/reducers/GameReducer';
import {
  gameRequested,
  moveRequested
} from '../../src/actions/GameActions';

describe('GameReducer', () => {
  it('has no games initially', () => {
    expect(gameReducer(undefined, {}).games).to.eql({});
  });

  it('adds number game to state', () => {
    const gameMap = gameReducer(undefined, gameRequested({
      type: 'guess_number',
    })).games;

    const games = Object.keys(gameMap).map((key) => gameMap[key]);

    expect(games.length).to.eq(1);

    const game = games[0];
    expect(game.id).to.be.a('number');
    expect(game.type).to.eq('guess_number');
    expect(game.status).to.eq('waiting_for_move');
    expect(game.target).to.be.a('number');
    expect(game.createdAt).to.be.a('number');
    expect(game.moves).to.eql([]);
  });

  it('adds word game to state', () => {
    const gameMap = gameReducer(undefined, gameRequested({
      type: 'guess_word',
    })).games;

    const games = Object.keys(gameMap).map((key) => gameMap[key]);

    expect(games.length).to.eq(1);

    const game = games[0];
    expect(game.id).to.be.a('number');
    expect(game.type).to.eq('guess_word');
    expect(game.status).to.eq('waiting_for_move');
    expect(game.target).to.be.a('string');
    expect(game.createdAt).to.be.a('number');
    expect(game.moves).to.eql([]);
  });

  it('adds move to number game when move requested', () => {
    const initialState = {
      games: {'game-id': {
        id: 'game-id',
        type: 'guess_number',
        status: 'waiting_for_move',
        target: 5,
        moves: []
      }}
    };

    const newGame = gameReducer(initialState, moveRequested({
      gameId: 'game-id', move: -1
    })).games['game-id'];
    expect(newGame.moves).to.eql([{comparedToAnswer: 'LT', move: -1}]);
  });

  it('adds move to word game when move requested', () => {
    const initialState = {
      games: {'game-id': {
        id: 'game-id',
        type: 'guess_word',
        status: 'waiting_for_move',
        target: 'foo',
        moves: []
      }}
    };

    const newGame = gameReducer(initialState, moveRequested({
      gameId: 'game-id', move: 'x'
    })).games['game-id'];
    expect(newGame.moves).to.eql([
      {correct: false, letterMatches: [['x', false]], move: 'x'}
    ]);
  });

  it('finishes number game when correct move', () => {
    const initialState = {
      games: {'game-id': {
        id: 'game-id',
        type: 'guess_number',
        status: 'waiting_for_move',
        target: 5,
        moves: []
      }}
    };

    const newGame = gameReducer(initialState, moveRequested({
      gameId: 'game-id', move: initialState.games['game-id'].target
    })).games['game-id'];
    expect(newGame.status).to.eq('finished');
  });

  it('finishes word game when correct move', () => {
    const initialState = {
      games: {'game-id': {
        id: 'game-id',
        type: 'guess_word',
        status: 'waiting_for_move',
        target: 5,
        moves: []
      }}
    };

    const newGame = gameReducer(initialState, moveRequested({
      gameId: 'game-id', move: initialState.games['game-id'].target
    })).games['game-id'];
    expect(newGame.status).to.eq('finished');
  });
});
