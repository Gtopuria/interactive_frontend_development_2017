import React, {Component} from 'react';
import MoveHistory from '../../components/GuessWord/MoveHistory';
import InputChangesOnSubmit from '../../components/InputChangesOnSubmit';

class Game extends Component {
  constructor(props) {
    super(props);
    this.state = {
      moves: [],
    };
  }

  onGuess(guessWord) {
    const result = this.props.game.guess(guessWord);
    this.setState({
      moves: this.state.moves.concat(result)
    });
  }

  render() {
    let PlayArea;
    const game = this.props.game;

    if (game.getStatus() === 'finished') {
      PlayArea = (
        <h3> You won! </h3>
      );
    } else {
      PlayArea = (
        <div>
          <p> Guess a 5 letter word </p>
          <InputChangesOnSubmit onSubmit={this.onGuess.bind(this)} type='text' />
        </div>
      );
    }
    return (
      <div className='game word-game'>
        <h2> Word Guess Game </h2>
        {PlayArea}
        <MoveHistory moves={this.state.moves} />
      </div>
    );
  }
}

Game.propTypes = {
  game: React.PropTypes.shape({
    guess: React.PropTypes.func.isRequired,
    getStatus: React.PropTypes.func.isRequired
  })
};

export default Game;
