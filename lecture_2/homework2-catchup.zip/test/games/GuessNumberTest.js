import NumberGame from '../../src/games/NumberGame';

describe('GuessNumber', () => {
  let game;
  beforeEach(() => {
    game = new NumberGame({targetNumber: 5, lowerBound: 0, upperBound: 10});
  });

  it('reports GT for guess greater than target', () => {
    const move = game.guess(6);
    expect(move).to.eql({comparedToAnswer: 'GT', guess: 6});
    expect(game.getStatus()).to.eql('waiting_for_move');
  });

  it('reports LT for guess lower than target', () => {
    const move = game.guess(4);
    expect(move).to.eql({comparedToAnswer: 'LT', guess: 4});
    expect(game.getStatus()).to.eql('waiting_for_move');
  });

  it('reports EQ for guess equal to target', () => {
    const move = game.guess(5);
    expect(move).to.eql({comparedToAnswer: 'EQ', guess: 5});
    expect(game.getStatus()).to.eql('finished');
  });
});
