const GAME_TYPE = 'number-game';

class NumberGame {
  static get type() {
    return GAME_TYPE;
  }

  static generate() {
    const upperBound = 9;
    const targetNumber = Math.floor(Math.random() * (upperBound + 1));
    return new NumberGame({targetNumber, lowerBound: 0, upperBound});
  }

  constructor({targetNumber, lowerBound, upperBound}) {
    this.targetNumber = targetNumber;
    this.lowerBound = lowerBound;
    this.upperBound = upperBound;
    this.status = 'waiting_for_move';
  }

  getType() {
    return GAME_TYPE;
  }

  getLowerBound() {
    return this.lowerBound;
  }

  getUpperBound() {
    return this.upperBound;
  }

  getStatus() {
    return this.status;
  }

  guess(guessNumber) {
    if (guessNumber == this.targetNumber) {
      this.status = 'finished';
      return {comparedToAnswer: 'EQ', guess: guessNumber};
    } else if (guessNumber > this.targetNumber) {
      return {comparedToAnswer: 'GT', guess: guessNumber};
    } else {
      return {comparedToAnswer: 'LT', guess: guessNumber};
    }
  }
}

export default NumberGame;
