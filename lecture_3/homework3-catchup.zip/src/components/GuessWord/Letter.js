import React from 'react';

const Letter = ({letter, correct}) => {
  const resultClass = correct ? 'correct' : 'incorrect';

  return (
    <span className={'letter ' + resultClass}>
      {letter}
    </span>
  );
};

Letter.propTypes = {
  letter: React.PropTypes.string.isRequired,
  correct: React.PropTypes.bool.isRequired
};

export default Letter;
