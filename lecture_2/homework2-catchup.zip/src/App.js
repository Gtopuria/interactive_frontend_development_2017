import React from 'react';

import NumberGameComponent from './components/GuessNumber/Game';
import NumberGame from './games/NumberGame';

const App = () => {
  return (
    <div className="app">
      <div className="app-header">
        <h1>Game Lobby</h1>
      </div>
      <NumberGameComponent game={NumberGame.generate()}/>
    </div>
  );
};

export default App;
