import React from 'react';
import {shallow} from 'enzyme';

import Move from '../../../src/components/GuessNumber/Move';

describe('GuessNumber/Move', () => {
  it('has correct class when guess was correct', () => {
    const result = shallow(<Move move={5} comparedToAnswer='EQ' />);
    expect(result.props().className).to.eq('move correct');
  });

  it('has incorrect class when guess was incorrect', () => {
    const result = shallow(<Move move={5} comparedToAnswer='LT' />);
    expect(result.props().className).to.eq('move incorrect');
  });
});
