import NumberGame from '../games/NumberGame';
import WordGame from '../games/WordGame';

const GAME_TYPE_TO_GAME = {
  guess_number: NumberGame,
  guess_word: WordGame
};

const payloadForwardingAction = (type) => (payload) => ({type, payload});

let gameCounter = 0;
export const GAME_REQUESTED = 'GAME_REQUESTED';
export const gameRequested = ({type}) => {
  gameCounter += 1;
  const gameId = gameCounter;
  const target = GAME_TYPE_TO_GAME[type].generateTarget();
  const createdAt = Date.now();

  return {
    type: GAME_REQUESTED,
    payload: {type, gameId, target, createdAt}
  };
};

export const MOVE_REQUESTED = 'MOVE_REQUESTED';
export const moveRequested = payloadForwardingAction(MOVE_REQUESTED);
