import NumberGame from '../games/NumberGame';
import WordGame from '../games/WordGame';

import {
  GAME_REQUESTED,
  MOVE_REQUESTED
} from '../actions/GameActions';

const initialState = {
  games: {}
};

const GAME_TYPE_TO_GAME = {
  guess_number: NumberGame,
  guess_word: WordGame
};

export default (state=initialState, action) => {
  const payload = action.payload;

  switch(action.type) {
    case GAME_REQUESTED: {
      const {type, gameId, target, createdAt} = payload;
      return {...state,
        games: {...state.games,
          [gameId]: {type, id: gameId, target, status: 'waiting_for_move', createdAt, moves: []}
        }
      };
    }

    case MOVE_REQUESTED: {
      const {gameId, move} = payload;
      const currentGameState = state.games[gameId];
      const GameLogic = GAME_TYPE_TO_GAME[currentGameState.type];
      const {
        move: newMove,
        game: newGame
      } = GameLogic.guess({move, target: currentGameState.target});
      const newMoves = currentGameState.moves.concat([newMove]);

      const newGameState = {...currentGameState,
        status: newGame.status,
        moves: newMoves
      };

      return {...state,
        games: {...state.games,
          [gameId]: newGameState
        }
      };
    }
    default:
      return state;
  }
};
