import React from 'react';
import {shallow} from 'enzyme';

import Game from '../../../src/containers/GuessWord/Game';
import MoveHistory from '../../../src/components/GuessWord/MoveHistory';
import InputChangesOnSubmit from '../../../src/components/InputChangesOnSubmit';
import WordGame from '../../../src/games/WordGame';

describe('GuessWord/Game', () => {
  let wordGame;
  beforeEach(() => {
    wordGame = new WordGame('paper');
  });

  it('passes guesses to MoveHistory', () => {
    const result = shallow(<Game game={wordGame} />);
    result.find(InputChangesOnSubmit).props().onSubmit('p');
    expect(result).to.contain(
      <MoveHistory moves={[{guess: 'p', correct: false, letterMatches: [['p', true]]}]} />
    );
  });

  it('initially has input', () => {
    const result = shallow(<Game game={wordGame} />);
    expect(result).to.have.exactly(1).descendants(InputChangesOnSubmit);
  });

  it('does not have input after guessing correctly', () => {
    const result = shallow(<Game game={wordGame} />);
    result.find(InputChangesOnSubmit).props().onSubmit('paper');
    expect(result).not.to.have.descendants(InputChangesOnSubmit);
  });
});
