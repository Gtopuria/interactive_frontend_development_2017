const candidateWords = [
  'paper',
  'grill',
  'basil',
  'hinge',
  'ruler'
];

const selectRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];

const GAME_TYPE = 'word-game';

class WordGame {
  static get type() {
    return GAME_TYPE;
  }

  static generate() {
    return new WordGame(selectRandom(candidateWords));
  }

  constructor(targetWord) {
    this.targetWord = targetWord;
    this.status = 'waiting_for_move';
  }

  getType() {
    return GAME_TYPE;
  }

  getStatus() {
    return this.status;
  }

  guess(guessWord) {
    const letterMatches = [];

    for(let i = 0; i < guessWord.length; i += 1) {
      const guessLetter = guessWord.charAt(i);
      const correct = guessLetter === this.targetWord.charAt(i);
      letterMatches.push([guessLetter, correct]);
    }

    const correct = guessWord === this.targetWord;
    if (correct) {
      this.status = 'finished';
    }

    return {
      correct: correct,
      letterMatches: letterMatches,
      guess: guessWord
    };
  }
}

export default WordGame;
