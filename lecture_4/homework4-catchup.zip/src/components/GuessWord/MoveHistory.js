import React from 'react';
import Move from './Move';

const MoveHistory = ({moves}) => {
  const moveHistory = moves.map((move, index) =>
    <Move
      move={move.move}
      letterMatches={move.letterMatches}
      correct={move.correct}
      key={index}
    />
  );

  if (moveHistory.length === 0) {
    return (<div className='move-history'/>);
  } else {
    return (
      <div className='move-history'>
        <p>Previous moves:</p>
        <div className='move-list'>
          {moveHistory}
        </div>
      </div>
    );
  }
};

MoveHistory.propTypes = {
  moves: React.PropTypes.array.isRequired
};

export default MoveHistory;
