import React from 'react';

const COMPARISON_TO_DESCRIPTION = {
  EQ: 'correct',
  LT: 'smaller than target',
  GT: 'greater than target'
};

const Move = ({move, comparedToAnswer}) => {
  const resultClass = comparedToAnswer == 'EQ' ? 'correct' : 'incorrect';

  return (
    <div className={'move ' + resultClass}>
      <p><i>{move}</i>: was {COMPARISON_TO_DESCRIPTION[comparedToAnswer]} </p>
    </div>
  );
};

Move.propTypes = {
  move: React.PropTypes.number.isRequired,
  comparedToAnswer: React.PropTypes.string.isRequired,
};

export default Move;
