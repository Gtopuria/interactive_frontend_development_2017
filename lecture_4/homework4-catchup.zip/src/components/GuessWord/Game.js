import React from 'react';
import MoveHistory from '../../components/GuessWord/MoveHistory';
import InputChangesOnSubmit from '../../components/InputChangesOnSubmit';

const Game = (props) => {
  let PlayArea;

  if (props.status === 'finished') {
    PlayArea = (
      <h3> You won! </h3>
    );
  } else {
    PlayArea = (
      <div>
        <p> Guess a 5 letter word </p>
        <InputChangesOnSubmit onSubmit={props.onMove} type='text' />
      </div>
    );
  }
  return (
    <div className='game word-game'>
      <h2> Word Guess Game </h2>
      {PlayArea}
      <MoveHistory moves={props.moves} />
    </div>
  );
};

Game.propTypes = {
  status: React.PropTypes.string.isRequired,
  onMove: React.PropTypes.func.isRequired,
  moves: React.PropTypes.array.isRequired
};

export default Game;
