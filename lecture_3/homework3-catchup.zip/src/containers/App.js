import React, {Component} from 'react';

import WordGameComponent from './GuessWord/Game';
import NumberGameComponent from './GuessNumber/Game';
import CreateGameButtons from '../components/CreateGameButtons';

import WordGame from '../games/WordGame';
import NumberGame from '../games/NumberGame';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {games: []};
    this.createWordGame = this.createWordGame.bind(this);
    this.createNumberGame = this.createNumberGame.bind(this);
  }

  createNumberGame() {
    this.setState({
      games: this.state.games.concat([NumberGame.generate()])
    });
  }

  createWordGame() {
    this.setState({
      games: this.state.games.concat([WordGame.generate()])
    });
  }

  render() {
    const games = this.state.games.map((game, index) => {
      if (game.getType() == NumberGame.type) {
        return <NumberGameComponent key={index} game={game} />;
      } else if (game.getType() == WordGame.type) {
        return <WordGameComponent key={index} game={game} />;
      }
    });
    return (
      <div className="app">
        <div className="app-header">
          <h1>Game Lobby</h1>
        </div>
        <CreateGameButtons createWordGame={this.createWordGame} createNumberGame={this.createNumberGame}/>
       <div className='games'>
          {games}
        </div>
      </div>
    );
  }
}

export default App;
