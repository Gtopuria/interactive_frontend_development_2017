import React from 'react';
import {shallow} from 'enzyme';

import Game from '../../../src/containers/GuessNumber/Game';
import MoveHistory from '../../../src/components/GuessNumber/MoveHistory';
import InputChangesOnSubmit from '../../../src/components/InputChangesOnSubmit';
import NumberGame from '../../../src/games/NumberGame';

describe('GuessNumber/Game', () => {
  let numberGame;
  beforeEach(() => {
    numberGame = new NumberGame({targetNumber: 5, upperBound: 10, lowerBound: 0});
  });

  it('passes guesses to MoveHistory', () => {
    const result = shallow(<Game game={numberGame} />);
    result.find(InputChangesOnSubmit).props().onSubmit(6);
    expect(result).to.contain(
      <MoveHistory moves={[{guess: 6, comparedToAnswer: 'GT'}]} />
    );
  });

  it('initially has input', () => {
    const result = shallow(<Game game={numberGame} />);
    expect(result).to.have.exactly(1).descendants(InputChangesOnSubmit);
  });

  it('does not have input after guessing correctly', () => {
    const result = shallow(<Game game={numberGame} />);
    result.find(InputChangesOnSubmit).props().onSubmit(5);
    expect(result).not.to.have.descendants(InputChangesOnSubmit);
  });
});
