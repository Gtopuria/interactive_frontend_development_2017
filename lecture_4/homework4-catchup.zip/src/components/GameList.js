import React from 'react';

import GuessWordGame from '../components/GuessWord/Game';
import GuessNumberGame from '../components/GuessNumber/Game';

const GameList = (props) => {
  const games = props.games.map((game, index) => {
    const onMove = (move) => props.onMove({move, gameId: game.id});
    const gameProps = {...game, key: index, onMove};
    if (game.type === 'guess_number') {
      return React.createElement(GuessNumberGame, gameProps);
    } else if (game.type === 'guess_word') {
      return React.createElement(GuessWordGame, gameProps);
    }
  });
  return (
    <div className='games'>
      {games}
    </div>
  );
};

GameList.propTypes = {
  games: React.PropTypes.array.isRequired
};

export default GameList;
