import WordGame from '../../src/games/WordGame';

describe('GuessWord', () => {
  let game;
  beforeEach(() => {
    game = new WordGame('paper');
  });

  it('reports correct letters but incorrect guess for substring guess', () => {
    const move = game.guess('pape');
    expect(move).to.eql({
      guess: 'pape',
      correct: false,
      letterMatches: [['p', true], ['a', true], ['p', true], ['e', true]]
    });
    expect(game.getStatus()).to.eql('waiting_for_move');
  });

  it('reports correct letters but incorrect guess for superstring guess', () => {
    const move = game.guess('paperboy');
    expect(move).to.eql({
      correct: false,
      guess: 'paperboy',
      letterMatches: [['p', true], ['a', true], ['p', true], ['e', true], ['r', true],
        ['b', false], ['o', false], ['y', false]]
    });
    expect(game.getStatus()).to.eql('waiting_for_move');
  });

  it('reports incorrect letters and incorrect guess for incorrect guess', () => {
    const move = game.guess('vinyl');
    expect(move).to.eql({
      correct: false,
      guess: 'vinyl',
      letterMatches: [['v', false], ['i', false], ['n', false], ['y', false], ['l', false]]
    });
    expect(game.getStatus()).to.eql('waiting_for_move');
  });

  it('reports correct letters and guess for correct guess', () => {
    const move = game.guess('paper');
    expect(move).to.eql({
      guess: 'paper',
      correct: true,
      letterMatches: [['p', true], ['a', true], ['p', true], ['e', true], ['r', true]]
    });
    expect(game.getStatus()).to.eql('finished');
  });
});
