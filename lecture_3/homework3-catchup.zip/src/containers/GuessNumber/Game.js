import React, {Component} from 'react';
import MoveHistory from '../../components/GuessNumber/MoveHistory';
import InputChangesOnSubmit from '../../components/InputChangesOnSubmit';

class Game extends Component {
  constructor(props) {
    super(props);
    this.state = {
      moves: [],
    };
    this.onGuess = this.onGuess.bind(this);
  }

  onGuess(guess) {
    const guessNumber = parseInt(guess);
    const result = this.props.game.guess(guessNumber);
    this.setState({
      moves: this.state.moves.concat(result)
    });
  }

  render() {
    let PlayArea;
    const game = this.props.game;

    if (game.getStatus() === 'finished') {
      PlayArea = (
        <h3> You won! </h3>
      );
    } else {
      PlayArea = (
        <div>
          <p> Guess a number from {game.getLowerBound()} to {game.getUpperBound()} </p>
          <InputChangesOnSubmit onSubmit={this.onGuess} type='number' />
        </div>
      );
    }

    return (
      <div className='game number-game'>
        <h3> Number Guess Game </h3>
        {PlayArea}
        <MoveHistory moves={this.state.moves} />
      </div>
    );
  }
}

Game.propTypes = {
  game: React.PropTypes.shape({
    guess: React.PropTypes.func.isRequired,
    getStatus: React.PropTypes.func.isRequired,
    getUpperBound: React.PropTypes.func.isRequired,
    getLowerBound: React.PropTypes.func.isRequired
  })
};

export default Game;
