import React from 'react';
import {shallow} from 'enzyme';

import CreateGameButtons from '../../src/components/CreateGameButtons';

describe('CreateGameButtons', () => {
  it('calls props.createNumberGame when create number game button clicked', () => {
    const createNumberGame = sinon.stub();
    const result = shallow(<CreateGameButtons createNumberGame={createNumberGame} createWordGame={sinon.stub()} />);
    result.find('.number-game').simulate('click');
    expect(createNumberGame).to.have.been.called;
  });

  it('calls props.createWordGame when create word game button clicked', () => {
    const createWordGame = sinon.stub();
    const result = shallow(<CreateGameButtons createNumberGame={sinon.stub()} createWordGame={createWordGame} />);
    result.find('.word-game').simulate('click');
    expect(createWordGame).to.have.been.called;
  });
});
