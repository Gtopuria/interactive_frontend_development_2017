import React from 'react';
import Letter from './Letter';

const Move = ({move, letterMatches, correct, status}) => {
  if (status === 'sending') {
    return (<p>Sending move</p>);
  }
  const resultClass = correct ? 'correct' : 'incorrect';
  const letters = letterMatches.map((correct, index) => {
    const letter = move[index];
    return <Letter key={index} letter={letter} correct={correct} />;
  });

  return (
    <div className={'move ' + resultClass}>
      {letters}
    </div>
  );
};

Move.propTypes = {
  move: React.PropTypes.string.isRequired,
  status: React.PropTypes.string.isRequired,
  letterMatches: React.PropTypes.array,
  correct: React.PropTypes.bool
};

export default Move;
