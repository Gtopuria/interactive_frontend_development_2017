import React from 'react';
import {shallow} from 'enzyme';

import App from '../../src/containers/App';
import CreateGameButtons from '../../src/components/CreateGameButtons';
import NumberGameComponent from '../../src/containers/GuessNumber/Game';
import WordGameComponent from '../../src/containers/GuessWord/Game';

describe('App', () => {
  it('initially renders App with no games', () => {
    const app = shallow(<App />);
    expect(app.find('games')).to.be.empty;
    expect(app).not.to.be.empty;
  });

  it('renders word game games if word game created', () => {
    const app = shallow(<App />);
    const createGameComponent = app.find(CreateGameButtons);
    createGameComponent.props().createWordGame();

    expect(app).to.have.exactly(1).descendants(WordGameComponent);
  });

  it('renders number game games if number game created', () => {
    const app = shallow(<App />);
    const createGameComponent = app.find(CreateGameButtons);
    createGameComponent.props().createNumberGame();

    expect(app).to.have.exactly(1).descendants(NumberGameComponent);
  });
});
