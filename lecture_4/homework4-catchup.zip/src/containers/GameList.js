import {connect} from 'react-redux';
import GameList from '../components/GameList';

import {moveRequested} from '../actions/GameActions';

const mapStateToProps = (state) => ({
  games: Object.values(state.games).sort((game) => -game.createdAt)
});

const mapDispatchToProps = (dispatch) => ({
  onMove: ({move, gameId}) => dispatch(moveRequested({move, gameId}))
});

export default connect(mapStateToProps, mapDispatchToProps)(GameList);
