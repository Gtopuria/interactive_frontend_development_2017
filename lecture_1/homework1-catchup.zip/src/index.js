import Counter from './Counter';

const counter = new Counter();

const button = document.createElement('button');

const updateButtonText = () => {
  button.innerHTML = `Clicked ${counter.getCount()} times`;
};

const onButtonClick = () => {
  counter.increase();
  updateButtonText();
};

button.onclick = onButtonClick;
updateButtonText();

document.body.appendChild(button);
