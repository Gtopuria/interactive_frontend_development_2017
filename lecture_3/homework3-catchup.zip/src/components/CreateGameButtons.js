import React from 'react';

const CreateGameButtons = (props) => {
  return (
    <div className='create-game-buttons'>
      <button className='number-game' onClick={props.createNumberGame}>Create Number game</button>
      <button className='word-game' onClick={props.createWordGame}>Create Word game</button>
    </div>
  );
};

CreateGameButtons.propTypes = {
  createNumberGame: React.PropTypes.func.isRequired,
  createWordGame: React.PropTypes.func.isRequired,
};

export default CreateGameButtons;
