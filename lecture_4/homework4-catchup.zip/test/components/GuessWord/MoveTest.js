import React from 'react';
import {render} from 'enzyme';

import Move from '../../../src/components/GuessWord/Move';

describe('GuessNumber/Move', () => {
  it('has correct letters when correct guess', () => {
    const result = render(
      <Move
        move='paper'
        letterMatches={[['p', true], ['a', true], ['p', true], ['e', true], ['r', true]]}
        correct={true}
      />);
    expect(result.html()).to.eql(
        '<div class="move correct">' +
          '<span class="letter correct">p</span>' +
          '<span class="letter correct">a</span>' +
          '<span class="letter correct">p</span>' +
          '<span class="letter correct">e</span>' +
          '<span class="letter correct">r</span>' +
        '</div>'
    );
  });

  it('has incorrect class when guess was incorrect', () => {
    const result = render(
      <Move
        move='pipe'
        letterMatches={[['p', true], ['i', false], ['p', true], ['e', true]]}
        correct={false}
      />);
    expect(result.html()).to.eql(
        '<div class="move incorrect">' +
          '<span class="letter correct">p</span>' +
          '<span class="letter incorrect">i</span>' +
          '<span class="letter correct">p</span>' +
          '<span class="letter correct">e</span>' +
        '</div>'
    );
  });
});
