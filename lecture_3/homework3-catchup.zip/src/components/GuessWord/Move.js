import React from 'react';
import Letter from './Letter';

const Move = ({guess, letterMatches, correct}) => {
  const resultClass = correct ? 'correct' : 'incorrect';
  const letters = letterMatches.map(([letter, correct], index) =>
    <Letter key={index} letter={letter} correct={correct} />);

  return (
    <div className={'move ' + resultClass}>
      {letters}
    </div>
  );
};

Move.propTypes = {
  guess: React.PropTypes.string.isRequired,
  letterMatches: React.PropTypes.array.isRequired,
  correct: React.PropTypes.bool.isRequired
};

export default Move;
